#Jayden Wigley
#Tkinter Database Project
#8/31/21
import sqlite3
from tkinter import *
from tkinter import ttk

root = Tk()
root.title("DGS, LLC Customer Sales")

#Customer String Vars
customerid = StringVar()
firstname = StringVar()
lastname = StringVar()
email = StringVar()
phone = StringVar()
address = StringVar()
state = StringVar()
city = StringVar()
zipcode = StringVar()

#Product String Vars
productcode = StringVar()
customercode = StringVar()
date = StringVar()
price = StringVar()

#Sales String Vars
productid = StringVar()
cid = StringVar()
purchasedate = StringVar()
quantity = StringVar()

def mainMenu():
    clearWindow()
    root.geometry('350x200')
    Label(root, text="DGS, LLC Customer Sales", font=('Arial', 20)).place(x=0, y=0)
    Button(root, text="Exit Program", font=('arial', 13), width=10, height=2, command=root.destroy).place(x=250, y=125)
    Button(root, text="Produce \nReport", font=('arial', 13), width=10, height=2, command=reportButton).place(x=0, y=125)
    Button(root, text="Edit/Add \nCustomers", font=('arial', 13), width=10, height=2, command=customerButton).place(x=0, y=60)
    Button(root, text="Edit/Add \nProducts", font=('arial', 13), width=10, height=2, command=productButton).place(x=125, y=60)
    Button(root, text="Edit/Add \nSales", font=('arial', 13), width=10, height=2, command=salesButton).place(x=250, y=60)

def reportButton():
    clearWindow()
    root.geometry('220x200')
    Label(root, text="Reports", font=('Arial', 20)).place(x=50, y=0)
    Button(root, text="Customer \nList", font=('arial', 13), width=10, height=2, command=customerListButton).place(x=0, y=60)
    Button(root, text="Product \nSales", font=('arial', 13), width=10, height=2, command=productListButton).place(x=120, y=60)
    Button(root, text="Home Screen", font=('arial', 13), width=12, height=2, command=mainMenu).place(x=60, y=125)

def customerListButton():
    clearWindow()
    root.geometry('700x275')
    conn = sqlite3.connect("DGS_LLC.db")
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM Customers""")
    customerList = cursor.fetchall()

    scrollbary = Scrollbar(root, orient=VERTICAL)
    scrollbarx = Scrollbar(root, orient=HORIZONTAL)
    tree = ttk.Treeview(root, columns=('ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Address', 'State', 'City', 'Zipcode'),
                       yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
    scrollbary.config(command=tree.yview)
    scrollbary.pack(side=RIGHT, fill=Y)
    scrollbarx.config(command=tree.xview)
    scrollbarx.pack(side=BOTTOM, fill=X)

    tree.heading('ID', text='ID', anchor=W)
    tree.heading('First Name', text='First Name', anchor=W)
    tree.heading('Last Name', text='Last Name', anchor=W)
    tree.heading('Email', text='Email', anchor=W)
    tree.heading('Phone', text='Phone', anchor=W)
    tree.heading('Address', text='Address', anchor=W)
    tree.heading('State', text='State', anchor=W)
    tree.heading('City', text='City', anchor=W)
    tree.heading('Zipcode', text='Zipcode', anchor=W)

    tree.column('#0', stretch=NO, minwidth=0, width=0)
    tree.column('#1', stretch=NO, minwidth=0, width=50)
    tree.column('#2', stretch=NO, minwidth=0, width=80)
    tree.column('#3', stretch=NO, minwidth=0, width=85)
    tree.column('#4', stretch=NO, minwidth=0, width=160)
    tree.column('#5', stretch=NO, minwidth=0, width=90)
    tree.column('#6', stretch=NO, minwidth=0, width=140)
    tree.column('#7', stretch=NO, minwidth=0, width=90)
    tree.column('#8', stretch=NO, minwidth=0, width=100)
    tree.column('#9', stretch=NO, minwidth=0, width=75)

    tree.pack()

    for i in range(len(customerList)):
        tree.insert('', i, text=i, values=(customerList[i]))

    Button(root, text='Return', height=0, width=10,command=reportButton).place(x=0,y=230)

def productListButton():
    clearWindow()
    root.geometry('700x275')
    conn = sqlite3.connect("DGS_LLC.db")
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM Products""")
    productList = cursor.fetchall()

    scrollbary = Scrollbar(root, orient=VERTICAL)
    scrollbarx = Scrollbar(root, orient=HORIZONTAL)
    tree = ttk.Treeview(root, columns=('ProductID', 'CustomerID', 'Date', 'Price'),
                       yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
    scrollbary.config(command=tree.yview)
    scrollbary.pack(side=RIGHT, fill=Y)
    scrollbarx.config(command=tree.xview)
    scrollbarx.pack(side=BOTTOM, fill=X)

    tree.heading('ProductID', text='ProductID', anchor=E)
    tree.heading('CustomerID', text='CustomerID', anchor=W)
    tree.heading('Date', text='Date', anchor=W)
    tree.heading('Price', text='Price', anchor=W)

    tree.column('#0', stretch=NO, minwidth=0, width=0)
    tree.column('#1', stretch=NO, minwidth=0, width=65)
    tree.column('#2', stretch=NO, minwidth=0, width=100)
    tree.column('#3', stretch=NO, minwidth=0, width=125)

    tree.pack()

    for i in range(len(productList)):
        tree.insert('', i, text=i, values=(productList[i]))

    Button(root, text='Return', height=0, width=10,command=reportButton).pack()

def customerButton():
    clearWindow()
    root.geometry('250x200')
    Label(root, text="Customer Database", font=('Arial', 20)).place(x=0, y=0)
    Button(root, text="Enter New \nCustomers", font=('arial', 13), width=10, height=2, command=newCust).place(x=0, y=60)
    Button(root, text="Edit \nCustomers", font=('arial', 13), width=10, height=2, command=lambda:getCustomer(customerid)).place(x=120, y=60)
    Button(root, text="Home Screen", font=('arial', 13), width=12, height=2, command=mainMenu).place(x=60, y=125)

def newCust():
    clearWindow()
    root.geometry('400x150')

    Label(root, text="Customer Info").grid(row=0,column=1)
    Label(root, text="Customer ID").grid(row=1,column=0)
    Entry(root, textvariable=customerid).grid(row=1,column=1)
    Label(root, text="First Name").grid(row=2, column=0)
    Entry(root, textvariable=firstname).grid(row=2, column=1)
    Label(root, text="Last Name").grid(row=3, column=0)
    Entry(root, textvariable=lastname).grid(row=3, column=1)
    Label(root, text="Email").grid(row=4, column=0)
    Entry(root, textvariable=email).grid(row=4, column=1)
    Label(root, text="Phone").grid(row=1, column=3)
    Entry(root, textvariable=phone).grid(row=1, column=4)
    Label(root, text="Address").grid(row=2, column=3)
    Entry(root, textvariable=address).grid(row=2, column=4)
    Label(root, text="State").grid(row=3, column=3)
    Entry(root, textvariable=state).grid(row=3, column=4)
    Label(root, text="City").grid(row=4, column=3)
    Entry(root, textvariable=city).grid(row=4, column=4)
    Label(root, text="Zipcode").grid(row=5, column=3)
    Entry(root, textvariable=zipcode).grid(row=5, column=4)
    Button(root, text="Submit Info", width=10, height=2, command=insertCustomer).place(x=0,y=108)
    Button(root, text="Return", width=10, height=2, command=customerButton).place(x=100, y=108)

def insertCustomer():
    conn = sqlite3.connect("DGS_LLC.db")
    insertQuery = """ INSERT INTO Customers
    (customerID, firstname, lastname, email, phone, address, state, city, zipcode)
    VALUES
    (?,?,?,?,?,?,?,?,?)"""
    CID = int(customerid.get())
    first = str(firstname.get())
    last = str(lastname.get())
    mail = str(email.get())
    number = int(phone.get())
    home = str(address.get())
    reside = str(state.get())
    town = str(city.get())
    area = int(zipcode.get())
    customerTuple = (CID, first, last, mail, number, home, reside, town, area)
    conn.execute(insertQuery, customerTuple)
    conn.commit()
    conn.close()

def productButton():
    clearWindow()
    root.geometry('250x200')
    Label(root, text="Product Database", font=('Arial', 20)).place(x=0, y=0)
    Button(root, text="Enter New \nProducts", font=('arial', 13), width=10, height=2, command=newProduct).place(x=0, y=60)
    Button(root, text="Edit \nProducts", font=('arial', 13), width=10, height=2).place(x=120, y=60)
    Button(root, text="Home Screen", font=('arial', 13), width=12, height=2, command=mainMenu).place(x=60, y=125)

def newProduct():
    clearWindow()
    root.geometry('250x150')

    Label(root, text="Product Info").grid(row=0, column=1)
    Label(root, text="Product Code").grid(row=1, column=0)
    Entry(root, textvariable=productcode).grid(row=1, column=1)
    Label(root, text="Customer Code").grid(row=2, column=0)
    Entry(root, textvariable=customercode).grid(row=2, column=1)
    Label(root, text="Date Purchased").grid(row=3, column=0)
    Entry(root, textvariable=date).grid(row=3, column=1)
    Label(root, text="Price Paid").grid(row=4, column=0)
    Entry(root, textvariable=price).grid(row=4, column=1)
    Button(root, text="Submit Info", width=10, height=2, command=insertProduct).place(x=0, y=108)
    Button(root, text="Return", width=10, height=2, command=productButton).place(x=100, y=108)

def insertProduct():
    conn = sqlite3.connect("DGS_LLC.db")
    insertQuery = """ INSERT INTO Products
    (productCode, customerCode, Date, Price)
    VALUES
    (?,?,?,?)"""
    PID = int(productcode.get())
    code = int(customercode.get())
    time = str(date.get())
    cost = str(price.get())
    customerTuple = (PID, code, time, cost)
    conn.execute(insertQuery, customerTuple)
    conn.commit()
    conn.close()

def salesButton():
    clearWindow()
    root.geometry('250x200')
    Label(root, text="Sales Database", font=('Arial', 20)).place(x=0, y=0)
    Button(root, text="Enter New \nSales", font=('arial', 13), width=10, height=2, command=newSales).place(x=0, y=60)
    Button(root, text="Edit \nSales", font=('arial', 13), width=10, height=2).place(x=120, y=60)
    Button(root, text="Home Screen", font=('arial', 13), width=12, height=2, command=mainMenu).place(x=60, y=125)

def newSales():
    clearWindow()
    root.geometry('250x150')

    Label(root, text="Sales Info").grid(row=0, column=1)
    Label(root, text="Product ID").grid(row=1, column=0)
    Entry(root, textvariable=productid).grid(row=1, column=1)
    Label(root, text="Customer ID").grid(row=2, column=0)
    Entry(root, textvariable=cid).grid(row=2, column=1)
    Label(root, text="Date Purchased").grid(row=3, column=0)
    Entry(root, textvariable=purchasedate).grid(row=3, column=1)
    Label(root, text="Quantity").grid(row=4, column=0)
    Entry(root, textvariable=quantity).grid(row=4, column=1)
    Button(root, text="Submit Info", width=10, height=2, command=insertSales).place(x=0, y=108)
    Button(root, text="Return", width=10, height=2, command=salesButton).place(x=100, y=108)

def insertSales():
    conn = sqlite3.connect("DGS_LLC.db")
    insertQuery = """ INSERT INTO Sales
        (productid, cid, purchasedate, quantity)
        VALUES
        (?,?,?,?)"""
    PID = int(productid.get())
    code = int(cid.get())
    time = str(purchasedate.get())
    cost = str(quantity.get())
    customerTuple = (PID, code, time, cost)
    conn.execute(insertQuery, customerTuple)
    conn.commit()
    conn.close()

def getCustomer(id):
    cursor = sqlite3.connect("DGS_LLC.db").cursor()
    cursor.execute("SELECT * FROM Customers")
    allCustomers = cursor.fetchall()

    for customer in allCustomers:
        if str(customer[0]) == str(id):
            return customer

def clearWindow():
    for widget in root.winfo_children():
        widget.destroy()

def removeFromDatabase(customerid, modify):
    conn = sqlite3.connect("DGS_LLC.db")
    conn.execute(f"""DELETE from Customers where id = {customerid}""")
    conn.commit()
    conn.close()

def modifyData():
    pass

conn = sqlite3.connect("DGS_LLC.db")
cursor = conn.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS Customers (
    customerID integer,
    firstname text,
    lastname text,
    email text,
    phone text,
    address text,
    state text,
    city text,
    zipcode integer
    ) """)

cursor.execute("""
    CREATE TABLE IF NOT EXISTS Products (
    productCode integer,
    customerCode integer,
    Date text,
    Price text
    ) """)

cursor.execute("""
    CREATE TABLE IF NOT EXISTS Sales (
    productID integer,
    cID integer,
    PurchaseDate text,
    Quantity integer
    ) """)

conn.commit()
conn.close()

mainMenu()
mainloop()