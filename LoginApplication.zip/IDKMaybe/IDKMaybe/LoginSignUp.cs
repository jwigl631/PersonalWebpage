﻿//Jayden Wigley
//Login Application
//12-7-21
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IDKMaybe
{
    public partial class LoginSignUp : Form
    {
        LoginModel user = new LoginModel();
        public LoginSignUp()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            user.UserName = SignUpUsername.Text;
            user.Password = SignUpPassword.Text;
            if (user.UserName == "" || user.Password == "" || user.Password.Contains(" ") || user.UserName.Contains(" ")) { MessageBox.Show("Can't Have A Null Username or Password"); }
            else {SignUpAccess.SaveUser(user);
                SignUpUsername.Text = "";
                SignUpPassword.Text = "";}
            
        }
        private void SignUpBack_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            List<LoginModel> Logins = SignUpAccess.LoadUser();
            foreach (var account in Logins)
            {
                if (account.UserName == LoginUsername.Text)
                {
                    if (account.Password == LoginPassword.Text)
                    {
                        MessageBox.Show("Login Successful");
                    }
                    else
                    {
                        MessageBox.Show("Login Failed");
                    }
                }
              
            }
            LoginUsername.Text = "";
            LoginPassword.Text = "";
        }
    }
}
