﻿//Jayden Wigley
//Login Application
//12-7-21
using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IDKMaybe
{
    class SignUpAccess
    {
        public static List<LoginModel> LoadUser()
        {
            using (IDbConnection conn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = conn.Query<LoginModel>("select * from PasswordManager", new DynamicParameters());
                return output.ToList();
            }
        }
        public static void SaveUser(LoginModel user)
        {
            try
            {
                using (IDbConnection conn = new SQLiteConnection(LoadConnectionString()))
                {
                    conn.Execute("insert into PasswordManager(Username, Password) values (@Username, @Password)", user);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                Console.WriteLine(ex);
                MessageBox.Show("Username is Null \nAccount not saved");
            }
        }
        private static string LoadConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["PasswordManager"].ConnectionString;
        }
    }
}
