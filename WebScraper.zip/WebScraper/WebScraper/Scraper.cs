﻿//Jayden Wigley
//Web Scraping Project
//11-15-21
using System;
using HtmlAgilityPack;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Diagnostics;

namespace WebScraper
{
    class Scraper
    {
        private List<string> Whitelist = new List<string>() {"Bitcoin", "Ethereum", "Solana", "Litecoin", "ChainLink"};
        private ObservableCollection<EntryModel> _entries = new ObservableCollection<EntryModel>();
        public ObservableCollection<EntryModel> Entries
        {
            get { return _entries; }
            set { _entries = value; }
        }
        public void ScraperData(string page)
        {
            var web = new HtmlWeb();
            var doc = web.Load(page);


            var Articles = doc.DocumentNode.SelectNodes("//*[@class = '_2mHoLKk1EmQ90Hj2VxwVKC _2cEwIPLxNCKyZSBxk7MyUQ Q0Cxwokka8qzW-qAyjdq6 pointer']");

            foreach (var article in Articles)
            {
                var coin = HttpUtility.HtmlDecode(article.SelectSingleNode(".//div[@class = 'text-left truncate _1hazOxgsUXq0rb-UgDZwNp _1GdBC6rgsSADLryaaGeEuX w8u1-Ks6zzfWwPQ23ywUj _36FIyjphKz71izCg1N-Uks']").InnerText);
                var price = HttpUtility.HtmlDecode(article.SelectSingleNode(".//div[@class = 'text-right _1hazOxgsUXq0rb-UgDZwNp LNc8C7U5Q_4hVq8G7HQHa _36FIyjphKz71izCg1N-Uks overflow-visible']").InnerText);
                if (Whitelist.Contains(coin))
                {
                    Debug.Print($"{coin}: ${price} USD");
                    _entries.Add(new EntryModel { Title = coin, Price = price });
                }
                else
                {
                    continue;
                }
            }

        }
    }
}
